package com.example.uasmobile;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    // membuat array data list buah
    String list_nama [] ={
            "Alpukat",
            "Apel",
            "Ceri",
            "Durian",
            "Jambuair",
            "Manggis",
            "Starberry"
    };
    String deskripsi [] ={
            "Buah Yang Enak, Mantap, Pokonya Gurih-Gurih Enyoyy",
            "Buah Yang Memiliki Kanduan Air Yang Banyak",
            "Buah Yang Kecil, Tapi Memiliki Rasa Yang Manis (Manisnya Kaya Kamu)Wks :v",
            "Buah Yang Memiliki Kulit Berduri Tapi Rasanya Sangat Enak Dan Baunya Sangat Mantap",
            "Buah Enak Lezak Dan Memiliki Kandungan Air",
            "Buah Yang Katanya Tidak Pernah Berbohong dan Rasanya Manis",
            "Buah Asem-Asem Manis Rasanya, Poko'e Enak (y) ;)"
    };

    // daftar gambar
    int list_gambar [] ={
            R.drawable.alpukat,
            R.drawable.apel,
            R.drawable.ceri,
            R.drawable.durian,
            R.drawable.jambuair,
            R.drawable.manggis,
            R.drawable.strawberry
    };
    // deklarasi widget ListView
    ListView LvBuah;

    LvBuah = (ListView)findViewById(R.id.LvBuah);
    // membuat sebuah adapter yang berfungsi untuk menampung data sementara sebelum di tampilkan ke dalam list view
    AdapterBuah adapter = new AdapterBuah(this, list_nama, list_gambar, deskripsi);
    //menampilkan / memasukan adapter ke dalam ListView
        LvBuah.setAdapter(adapter);
    //memberikan event ketika listview diklik
        LvBuah.setOnItemClickListener(new AdapterView.OnItemClickListener() {
        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            // inten ke detail.java dengan mengirimkan parameter yang berisi nama dan gambar
            Intent a = new Intent(getApplicationContext(), DetailActivity.class);
            //kirimkan parameter
            a.putExtra("Nama", list_nama [position]);
            a.putExtra("Gambar", list_gambar [position]);
            a.putExtra("Deskripsi", deskripsi [position]);

            //kirimkan ke detail.java
            startActivity(a);
        }
    })

    // class di dalam class
    private class AdapterBuah extends ArrayAdapter{
        String list_nama [];
        String deskripsi [];
        int list_gambar [];
        Activity activity;
        //konstruktor
        public AdapterBuah(MainActivity mainActivity, String[] list_nama, int[] list_gambar, String [] deskripsi) {
            super(mainActivity, R.layout.list_buah, list_nama);
            this.list_gambar = list_gambar;
            activity = mainActivity;
            this.list_nama = list_nama;
            this.deskripsi = deskripsi;

        }

        //menthode yang digunakan untuk memanggil layout list_buah dan mengenalkan widgetnya
        @NonNull
        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            // panggil layout list_buah
            LayoutInflater inflater = (LayoutInflater)activity.getLayoutInflater();
            View v = inflater.inflate(R.layout.list_buah, null);
            // kenalkan widget yang ada pada list buah
            ImageView gambar;
            TextView nama;

            //casting widget id
            gambar = (ImageView)v.findViewById(R.id.IvGambarBuah);
            nama = (TextView)v.findViewById(R.id.TxtNamaBuah);


            // set data kedalam image
            gambar.setImageResource(list_gambar[position]);
            nama.setText(list_nama[position]);


            return v;
        }
    }
    import android.app.Activity;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Layout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.List;

    public class MainActivity extends AppCompatActivity {
        // membuat array data list buah
        String list_nama[] = {
                "Alpukat",
                "Apel",
                "Ceri",
                "Durian",
                "Jambuair",
                "Manggis",
                "Starberry"
        };
        String deskripsi[] = {
                "Buah Yang Enak, Mantap, Pokonya Gurih-Gurih Enyoyy",
                "Buah Yang Memiliki Kanduan Air Yang Banyak",
                "Buah Yang Kecil, Tapi Memiliki Rasa Yang Manis (Manisnya Kaya Kamu)Wks :v",
                "Buah Yang Memiliki Kulit Berduri Tapi Rasanya Sangat Enak Dan Baunya Sangat Mantap",
                "Buah Enak Lezak Dan Memiliki Kandungan Air",
                "Buah Yang Katanya Tidak Pernah Berbohong dan Rasanya Manis",
                "Buah Asem-Asem Manis Rasanya, Poko'e Enak (y) ;)"
        };

        // daftar gambar
        int list_gambar[] = {
                R.drawable.alpukat,
                R.drawable.apel,
                R.drawable.ceri,
                R.drawable.durian,
                R.drawable.jambuair,
                R.drawable.manggis,
                R.drawable.strawberry
        };


        ListView LvBuah;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);

            LvBuah = (ListView) findViewById(R.id.LvBuah);
            // membuat sebuah adapter yang berfungsi untuk menampung data sementara sebelum di tampilkan ke dalam list view
            AdapterBuah adapter = new AdapterBuah(this, list_nama, list_gambar, deskripsi);
            //menampilkan / memasukan adapter ke dalam ListView
            LvBuah.setAdapter(adapter);
            //memberikan event ketika listview diklik
            LvBuah.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    // inten ke detail.java dengan mengirimkan parameter yang berisi nama dan gambar
                    Intent a = new Intent(getApplicationContext(), DetailActivity.class);
                    //kirimkan parameter
                    a.putExtra("Nama", list_nama[position]);
                    a.putExtra("Gambar", list_gambar[position]);
                    a.putExtra("Deskripsi", deskripsi[position]);

                    //kirimkan ke detail.java
                    startActivity(a);
                }
            });


        }

        // class di dalam class
        private class AdapterBuah extends ArrayAdapter {
            String list_nama[];
            String deskripsi[];
            int list_gambar[];
            Activity activity;

            //konstruktor
            public AdapterBuah(MainActivity mainActivity, String[] list_nama, int[] list_gambar, String[] deskripsi) {
                super(mainActivity, R.layout.list_buah, list_nama);
                this.list_gambar = list_gambar;
                activity = mainActivity;
                this.list_nama = list_nama;
                this.deskripsi = deskripsi;

            }


            //menthode yang digunakan untuk memanggil layout list_buah dan mengenalkan widgetnya
            @NonNull
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                // panggil layout list_buah
                LayoutInflater inflater = (LayoutInflater) activity.getLayoutInflater();
                View v = inflater.inflate(R.layout.list_buah, null);
                // kenalkan widget yang ada pada list buah
                ImageView gambar;
                TextView nama;

                //casting widget id
                gambar = (ImageView) v.findViewById(R.id.IvGambarBuah);
                nama = (TextView) v.findViewById(R.id.TxtNamaBuah);

                // set data kedalam image
                gambar.setImageResource(list_gambar[position]);
                nama.setText(list_nama[position]);

                return v;
            }
        }
    }
}